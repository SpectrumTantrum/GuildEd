"use client";

import { useState } from "react";
import { BookOpen, Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Brain, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function LearningPanel() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(70);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalTime, setTotalTime] = useState(300); // 5分钟示例
  const [activeTab, setActiveTab] = useState("text");

  const togglePlay = () => setIsPlaying(!isPlaying);
  const toggleMute = () => setVolume(volume === 0 ? 70 : 0);

  return (
    <Card className="p-6 rounded-xl">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          学习内容
        </h3>
        <Button variant="secondary" size="sm" className="flex items-center gap-1">
          <Brain className="w-4 h-4" />
          个性化学习
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="text">文本</TabsTrigger>
          <TabsTrigger value="visual">可视化</TabsTrigger>
          <TabsTrigger value="audio">音频</TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="space-y-4">
          <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
            <h4 className="font-medium mb-2">神经网络基础</h4>
            <p className="text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
              神经网络是一种模拟人脑结构和功能的计算模型，由大量相互连接的神经元组成。它通过学习数据中的模式来进行预测和决策。
              <br /><br />
              神经网络的基本组成部分包括输入层、隐藏层和输出层。每一层都包含多个神经元，神经元之间通过权重连接。
            </p>
          </div>
        </TabsContent>

        <TabsContent value="visual" className="space-y-4">
          <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-lg flex justify-center items-center h-64">
            <div className="text-center">
              <Lightbulb className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
              <p className="text-sm text-neutral-700 dark:text-neutral-300">
                3D 可视化内容将在这里显示
              </p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="audio" className="space-y-4">
          <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm">
                <div className="font-medium">神经网络基础讲解</div>
                <div className="text-xs text-neutral-600 dark:text-neutral-400">AI 导师</div>
              </div>
              <Button variant="secondary" size="sm">
                下载
              </Button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-600 dark:text-neutral-400">
                <span>{Math.floor(currentTime / 60)}:{(currentTime % 60).toString().padStart(2, '0')}</span>
                <span>{Math.floor(totalTime / 60)}:{(totalTime % 60).toString().padStart(2, '0')}</span>
              </div>
              <Slider
                value={[currentTime]}
                max={totalTime}
                step={1}
                onValueChange={(value) => setCurrentTime(value[0])}
                className="w-full"
              />
            </div>

            <div className="flex items-center justify-center gap-4">
              <Button variant="secondary" size="icon" className="rounded-full">
                <SkipBack className="w-5 h-5" />
              </Button>
              <Button
                onClick={togglePlay}
                className="rounded-full bg-blue-600 hover:bg-blue-700 text-white"
                size="icon"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
              <Button variant="secondary" size="icon" className="rounded-full">
                <SkipForward className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2">
                <Button
                  onClick={toggleMute}
                  variant="secondary"
                  size="icon"
                  className="rounded-full"
                >
                  {volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </Button>
                <Slider
                  value={[volume]}
                  max={100}
                  step={1}
                  onValueChange={(value) => setVolume(value[0])}
                  className="w-24"
                />
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}