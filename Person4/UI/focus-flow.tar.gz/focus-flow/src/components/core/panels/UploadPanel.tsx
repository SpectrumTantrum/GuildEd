"use client";

import { useState } from "react";
import { Upload, FileText, Book, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export function UploadPanel() {
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState("");
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setFileName(e.target.files[0].name);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    
    setUploading(true);
    // 模拟上传过程
    setTimeout(() => {
      setUploading(false);
      alert(`文件 ${fileName} 上传成功！`);
      setFile(null);
      setFileName("");
    }, 2000);
  };

  return (
    <Card className="p-6 border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-xl">
      <div className="flex flex-col items-center justify-center text-center">
        <Upload className="w-12 h-12 mb-4 text-neutral-500 dark:text-neutral-400" />
        <h3 className="text-xl font-semibold mb-2">上传课程材料</h3>
        <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-6">
          支持 PDF、文档等格式，我们将把内容转换为交互式 3D 学习环境
        </p>
        
        <div className="w-full max-w-md">
          <Input
            type="file"
            onChange={handleFileChange}
            className="mb-4"
            accept=".pdf,.doc,.docx"
          />
          {fileName && (
            <div className="mb-4 p-3 bg-neutral-100 dark:bg-neutral-800 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
                <span className="text-sm">{fileName}</span>
              </div>
              <Button
                onClick={handleUpload}
                disabled={uploading}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {uploading ? "上传中..." : "上传"}
              </Button>
            </div>
          )}
        </div>
        
        <div className="mt-6 flex gap-4 flex-wrap justify-center">
          <div className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400">
            <Book className="w-4 h-4" />
            <span>PDF 文档</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400">
            <Brain className="w-4 h-4" />
            <span>自动转换为 3D 内容</span>
          </div>
        </div>
      </div>
    </Card>
  );
}