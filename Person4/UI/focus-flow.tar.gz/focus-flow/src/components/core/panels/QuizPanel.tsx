"use client";

import { useState } from "react";
import { Puzzle, Check, X, Brain, Clock, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";

export function QuizPanel() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60); // 60秒倒计时

  const questions = [
    {
      id: 1,
      question: "神经网络的基本组成部分不包括以下哪项？",
      options: [
        { id: "A", text: "输入层", correct: false },
        { id: "B", text: "隐藏层", correct: false },
        { id: "C", text: "输出层", correct: false },
        { id: "D", text: "控制层", correct: true }
      ]
    },
    {
      id: 2,
      question: "以下哪种激活函数在神经网络中最常用？",
      options: [
        { id: "A", text: "线性函数", correct: false },
        { id: "B", text: "Sigmoid函数", correct: false },
        { id: "C", text: "ReLU函数", correct: true },
        { id: "D", text: "阶跃函数", correct: false }
      ]
    },
    {
      id: 3,
      question: "神经网络通过什么过程学习？",
      options: [
        { id: "A", text: "前向传播", correct: false },
        { id: "B", text: "反向传播", correct: true },
        { id: "C", text: "随机搜索", correct: false },
        { id: "D", text: "遗传算法", correct: false }
      ]
    }
  ];

  const handleAnswerSelect = (optionId: string) => {
    setSelectedAnswer(optionId);
  };

  const handleSubmitAnswer = () => {
    if (!selectedAnswer) return;
    
    const currentQ = questions[currentQuestion];
    const correctOption = currentQ.options.find(opt => opt.correct);
    const isAnswerCorrect = selectedAnswer === correctOption?.id;
    
    setIsCorrect(isAnswerCorrect);
    setShowFeedback(true);
    
    if (isAnswerCorrect) {
      setScore(prev => prev + 1);
    }
    
    // 2秒后进入下一题
    setTimeout(() => {
      setShowFeedback(false);
      setSelectedAnswer(null);
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(prev => prev + 1);
        setTimeLeft(60);
      }
    }, 2000);
  };

  // 模拟倒计时
  useState(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitAnswer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  });

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const isQuizComplete = currentQuestion >= questions.length - 1 && showFeedback;

  return (
    <Card className="p-6 rounded-xl">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <Puzzle className="w-5 h-5" />
          知识测验
        </h3>
        <div className="flex items-center gap-2 text-sm">
          <Clock className="w-4 h-4" />
          <span>{timeLeft}秒</span>
        </div>
      </div>

      <Progress value={progress} className="h-2 mb-6" />
      
      {!isQuizComplete ? (
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-medium mb-4">
              问题 {currentQuestion + 1}/{questions.length}
            </h4>
            <p className="text-base mb-6">
              {questions[currentQuestion].question}
            </p>
          </div>

          <RadioGroup
            value={selectedAnswer}
            onValueChange={handleAnswerSelect}
            className="space-y-3"
          >
            {questions[currentQuestion].options.map(option => (
              <div key={option.id} className="flex items-center space-x-2">
                <RadioGroupItem
                  value={option.id}
                  id={`option-${option.id}`}
                  className={showFeedback ? (option.correct ? "border-green-500 bg-green-50" : selectedAnswer === option.id ? "border-red-500 bg-red-50" : "") : ""}
                />
                <Label
                  htmlFor={`option-${option.id}`}
                  className={`flex-1 py-2 px-3 rounded-md cursor-pointer ${showFeedback ? (option.correct ? "bg-green-50 text-green-700" : selectedAnswer === option.id ? "bg-red-50 text-red-700" : "") : "hover:bg-neutral-100"}`}
                >
                  {option.text}
                </Label>
                {showFeedback && option.correct && (
                  <Check className="w-5 h-5 text-green-500" />
                )}
                {showFeedback && !option.correct && selectedAnswer === option.id && (
                  <X className="w-5 h-5 text-red-500" />
                )}
              </div>
            ))}
          </RadioGroup>

          <Button
            onClick={handleSubmitAnswer}
            disabled={!selectedAnswer || showFeedback}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {showFeedback ? "下一题" : "提交答案"}
          </Button>
        </div>
      ) : (
        <div className="text-center py-8">
          <Award className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
          <h4 className="text-xl font-semibold mb-2">测验完成！</h4>
          <p className="text-lg mb-4">
            你的得分：{score}/{questions.length}
          </p>
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-6">
            {score === questions.length
              ? "太棒了！你完全掌握了这些知识！"
              : score >= questions.length / 2
              ? "做得不错！继续努力！"
              : "再试一次，你可以做得更好！"}
          </p>
          <Button
            onClick={() => {
              setCurrentQuestion(0);
              setSelectedAnswer(null);
              setShowFeedback(false);
              setScore(0);
              setTimeLeft(60);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            重新测验
          </Button>
        </div>
      )}
    </Card>
  );
}