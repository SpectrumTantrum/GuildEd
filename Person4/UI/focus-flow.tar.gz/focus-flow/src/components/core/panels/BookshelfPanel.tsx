"use client";

import { useState } from "react";
import { Book, Link, Star, FileText, Globe, Video, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export function BookshelfPanel() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const resources = [
    {
      id: 1,
      title: "神经网络基础教程",
      type: "article",
      source: "Medium",
      relevance: 95,
      summary: "这篇文章详细介绍了神经网络的基本原理，包括神经元结构、激活函数和反向传播算法。",
      link: "#"
    },
    {
      id: 2,
      title: "深度学习实战",
      type: "book",
      source: "O'Reilly",
      relevance: 90,
      summary: "一本实用的深度学习指南，包含大量代码示例和实际应用案例。",
      link: "#"
    },
    {
      id: 3,
      title: "神经网络可视化",
      type: "video",
      source: "YouTube",
      relevance: 85,
      summary: "一个直观的视频教程，通过动画展示神经网络的工作原理。",
      link: "#"
    },
    {
      id: 4,
      title: "AI研究最新进展",
      type: "article",
      source: "ArXiv",
      relevance: 88,
      summary: "综述了2025年人工智能领域的重要研究成果和发展趋势。",
      link: "#"
    }
  ];

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || resource.type === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "book":
        return <Book className="w-4 h-4" />;
      case "article":
        return <FileText className="w-4 h-4" />;
      case "video":
        return <Video className="w-4 h-4" />;
      default:
        return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <Card className="p-6 rounded-xl">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <Book className="w-5 h-5" />
          书架资源
        </h3>
        <Button variant="secondary" size="sm" className="flex items-center gap-1">
          <Search className="w-4 h-4" />
          搜索资源
        </Button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <Input
            type="text"
            placeholder="搜索学习资源..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex gap-2 mt-4">
          <Button
            variant={activeCategory === "all" ? "default" : "secondary"}
            size="sm"
            onClick={() => setActiveCategory("all")}
          >
            全部
          </Button>
          <Button
            variant={activeCategory === "article" ? "default" : "secondary"}
            size="sm"
            onClick={() => setActiveCategory("article")}
          >
            文章
          </Button>
          <Button
            variant={activeCategory === "book" ? "default" : "secondary"}
            size="sm"
            onClick={() => setActiveCategory("book")}
          >
            书籍
          </Button>
          <Button
            variant={activeCategory === "video" ? "default" : "secondary"}
            size="sm"
            onClick={() => setActiveCategory("video")}
          >
            视频
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredResources.map(resource => (
          <Card key={resource.id} className="p-4 border border-neutral-200 dark:border-neutral-700">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                {getTypeIcon(resource.type)}
                <Badge variant="secondary" className="text-xs">
                  {resource.type}
                </Badge>
              </div>
              <div className="flex items-center gap-1 text-sm">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span>{resource.relevance}%</span>
              </div>
            </div>
            
            <h4 className="font-medium mb-2">{resource.title}</h4>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-3 line-clamp-2">
              {resource.summary}
            </p>
            
            <div className="flex items-center justify-between">
              <span className="text-xs text-neutral-500">来源: {resource.source}</span>
              <Button
                variant="secondary"
                size="sm"
                className="flex items-center gap-1"
                onClick={() => window.open(resource.link, "_blank")}
              >
                <Link className="w-4 h-4" />
                查看
              </Button>
            </div>
          </Card>
        ))}
      </div>
      
      {filteredResources.length === 0 && (
        <div className="text-center py-8">
          <Search className="w-12 h-12 mx-auto mb-4 text-neutral-400" />
          <p className="text-neutral-600 dark:text-neutral-400">
            未找到匹配的资源
          </p>
        </div>
      )}
    </Card>
  );
}