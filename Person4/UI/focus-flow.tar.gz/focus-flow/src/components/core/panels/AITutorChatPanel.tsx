"use client";

import { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, Brain, Loader2, Mic, Paperclip } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export function AITutorChatPanel() {
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([
    {
      role: "assistant",
      content: "你好！我是你的 AI 学习导师。有什么我可以帮助你的吗？"
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    setIsLoading(true);

    // 模拟 AI 响应
    setTimeout(() => {
      const assistantResponse = "这是一个模拟的 AI 响应。在实际应用中，这里会连接到真实的 AI 模型，如 Claude 或 GPT-4，以提供智能的学习辅助。";
      setMessages(prev => [...prev, { role: "assistant", content: assistantResponse }]);
      setIsLoading(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="p-6 rounded-xl">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <Brain className="w-5 h-5" />
          AI 导师
        </h3>
        <Button variant="secondary" size="sm">
          新对话
        </Button>
      </div>

      <div className="h-80 overflow-y-auto mb-4 space-y-4 p-2 border border-neutral-200 dark:border-neutral-700 rounded-lg">
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] p-3 rounded-lg ${message.role === "user" ? "bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-100" : "bg-neutral-100 dark:bg-neutral-800"}`}
            >
              <p className="text-sm">{message.content}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[80%] p-3 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">AI 正在思考...</span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <div className="flex gap-2">
        <Button variant="secondary" size="icon" className="rounded-full">
          <Mic className="w-4 h-4" />
        </Button>
        <Button variant="secondary" size="icon" className="rounded-full">
          <Paperclip className="w-4 h-4" />
        </Button>
        <Input
          type="text"
          placeholder="输入你的问题..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          className="flex-1"
        />
        <Button
          onClick={handleSendMessage}
          disabled={!input.trim() || isLoading}
          className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}