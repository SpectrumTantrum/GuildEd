import { UploadPanel } from "@/components/core/panels/UploadPanel";
import { LearningPanel } from "@/components/core/panels/LearningPanel";
import { QuizPanel } from "@/components/core/panels/QuizPanel";
import { BookshelfPanel } from "@/components/core/panels/BookshelfPanel";
import { AITutorChatPanel } from "@/components/core/panels/AITutorChatPanel";

export default function Home() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-50 font-sans dark:bg-black">
      <main className="flex min-h-screen w-full max-w-4xl flex-col items-center justify-between py-16 px-4 bg-white dark:bg-black">
        <h1 className="text-4xl font-bold mb-8 text-center">FocusFlow 3D</h1>
        <div className="w-full space-y-8">
          <UploadPanel />
          <LearningPanel />
          <QuizPanel />
          <BookshelfPanel />
          <AITutorChatPanel />
        </div>
      </main>
    </div>
  );
}